                                                                                                                                                                                                                                                                                                                                                                                                                                                /*
 * LimeSurvey
 * Copyright (C) 2007 The LimeSurvey Project Team / Carsten Schmitz
 * All rights reserved.
 * License: GNU/GPL License v2 or later, see LICENSE.php
 * LimeSurvey is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 * 
 * 
 * Description: Javascript file for templates. Put JS-functions for your template here.
 *  
 * 
 * $Id:$
 */


/*
 * The function focusFirst puts the Focus on the first non-hidden element in the Survey. 
 * 
 * Normally this is the first input field (the first answer).
 */
function focusFirst(Event)
{
    var i=0;
	// count up as long as the elements are hidden
	while(document.forms[0].elements[i].type == "hidden" &&
		document.forms[0].elements[i].style.visibility == 'visible')
	{
		i++;
	}
	// put focus on the element we just counted.
	if (document.forms[0].elements[i].type == "hidden" &&
		document.forms[0].elements[i].style.visibility == 'visible')
	{
		document.forms[0].elements[i].focus();
	}
	return;
}
/*
 * The focusFirst function is added to the eventlistener, when the page is loaded.
 * 
 * This can be used to start other functions on pageload as well. Just put it inside the 'ready' function block
 */

/** Uncomment if you want to use the focusFirst function

$(document).ready(function(){
   focusFirst();
})
	
**/

function correctPNG() // correctly handle PNG transparency in Win IE 5.5 & 6.
{
   var arVersion = navigator.appVersion.split("MSIE")
   var version = parseFloat(arVersion[1])
   if ((version >= 5.5) && (version<7) && (document.body.filters)) 
   {
      for(var i=0; i<document.images.length; i++)
      {
         var img = document.images[i]
         var imgName = img.src.toUpperCase()
         if (imgName.substring(imgName.length-3, imgName.length) == "PNG")
         {
            var imgID = (img.id) ? "id='" + img.id + "' " : "";
            var imgClass = (img.className) ? "class='" + img.className + "' " : "";
            var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' ";
            var imgStyle = "display:inline-block;" + img.style.cssText;
            if (img.align == "left") imgStyle = "float:left;" + imgStyle;
            if (img.align == "right") imgStyle = "float:right;" + imgStyle;
            if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle;
            var strNewHTML = "<span " + imgID + imgClass + imgTitle
            + " style=" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";"
            + "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader"
            + "(src='" + img.src + "', sizingMethod='scale');></span>" 
            img.outerHTML = strNewHTML
            i = i-1
         }
      }
   }    
}


$(document).ready(function(){
   //remove class from all slider questions to make template Limesurvey 2.05 compatible
   $("div.ui-slider-horizontal").removeClass("multinum-slider");
});

$(document).ready(function(){   

var root = $('head link[href*="template.css"]').attr('href').replace(/template.css/, '');
		
	// Apply images to radios 
	$('input[type="radio"]').imageTick({ 
		// Image to use as a selected state of the radio
		tick_image_path: root +"radio.png", 
		// Image to use as a non-selected state 
		no_tick_image_path: root +"no_radio.png", 
		// Class to apply to all radio images that are dynamically created 
		image_tick_class: "radios"
	}); 
	
	// Apply images to checkboxes 
	$('input[type="checkbox"]').not('#confirm-clearall').imageTick({ 
		// Image to use as a selected state of the checkbox  
		tick_image_path: root +"check.png",  
		// Image to use as a non-selected state 
		no_tick_image_path: root +"no_check.png", 
		// Class to apply to all checkbox images that are dynamically created 
		image_tick_class: "checkboxes" 
	}); 

})

$(document).ready(function(){  
    
    // A custom plugin to multiple question types in an array
	// Author - Tony Partner - partnersurveys.com
	(function($){
	
		$.fn.multiTypeArray = function(options) {
		
			// The defaults, extended and modified with any passed in the function call
			var opts = $.extend( {
				questionCount: 2,
				equalWidths: false
			}, options);
			
			return this.each(function(i) {
					
				var thisQuestion = $(this);
				var addedCols = opts.questionCount - 1;	
				var rowCount = $('table.subquestions-list tbody tr', thisQuestion).length;
		
				// Add some classes
				$('body').addClass('with-mta');
				thisQuestion.addClass('multi-type-array');
				$('table.subquestions-list tbody tr', thisQuestion).addClass('mta-sub-question-row');
				$('table.subquestions-list thead th, table.subquestions-list tbody td', thisQuestion).addClass('mta-question-1').attr('data-mta-question', 1);
				
				// Cleanup
				$('col, th.answertext', thisQuestion).removeAttr('width');
				
				// Extra row in the head
				var newHeadRow = $('table.subquestions-list thead tr:eq(0)', thisQuestion).clone();
				newHeadRow.addClass('head-row-2  class="mta-inserted-row"');
				$('td, th', newHeadRow).html('');
				$('table.subquestions-list thead tr:eq(0)', thisQuestion).addClass('head-row-1').after(newHeadRow);
				
				// The columns loop...
				for (i = 0; i < addedCols; i++) {
					
					var nextQuestion = thisQuestion.nextAll('.question-wrapper:eq('+i+')');
					nextQuestion.hide();
					var qIndex = i+2;
					
					// Column header
					var colSpan = $('table.subquestions-list thead th', nextQuestion).length;
					if(colSpan == 0) {
						colSpan = 1;
					}
					$('.head-row-1', thisQuestion).append('<th class="mta-inserted-cell mta-question-'+qIndex+' spacer" /><th class="mta-inserted-cell mta-question-'+qIndex+'" data-mta-question="'+qIndex+'" colspan="'+colSpan+'">'+$('.questiontext', nextQuestion).html()+'</th>');
					
					// Column option headers
					if($('table.subquestions-list thead th', nextQuestion).length > 0) {
						$('.head-row-2', thisQuestion).append('<th class="mta-inserted-cell mta-question-'+qIndex+' spacer" />');
						$('table.subquestions-list thead th', nextQuestion).each(function(i) {
							$('.head-row-2', thisQuestion).append('<th class="mta-inserted-cell mta-question-'+qIndex+' mta-option-'+(i+1)+'" data-mta-question="'+qIndex+'">'+$(this).html()+'</th>');
						});	
					}
					else {
						$('.head-row-2', thisQuestion).append('<th class="mta-inserted-cell mta-question-'+qIndex+' spacer" />');
						$('.head-row-2', thisQuestion).append('<th class="mta-inserted-cell mta-question-'+qIndex+' mta-option-'+(i+1)+'" data-mta-question="'+qIndex+'" />');
					}
					//else {
					//	$('.head-row-1 th.mta-question-'+qIndex+'', thisQuestion).attr('rowspan', 2);
					//}
					
					// Answer options
					$('table.subquestions-list tbody tr', nextQuestion).each(function(i) {
						var thisIndex = i;
						$('.mta-sub-question-row:eq('+thisIndex+')', thisQuestion).append('<td class="mta-inserted-cell mta-question-'+qIndex+' spacer" />');
						$('td', this).each(function(i) {
							$(this).addClass('mta-inserted-cell mta-question-'+qIndex+' mta-option-'+(i+1)+'').attr('data-mta-question', qIndex)
							$('.mta-sub-question-row:eq('+thisIndex+')', thisQuestion).append(this);
						});	
					});	
				}
				
				//$('#outer-wrapper').width($('table.subquestions-list', thisQuestion).width()+20);
			});
		};
	})( jQuery );

});

// JQuery plugin to vertically centre elements, taken from
// http://stackoverflow.com/questions/17715227/vertical-align-using-jquery-for-all-devices
jQuery.fn.verticalCenter = function ()
{
  return this
    .css("margin-top",($(this).parent().height() - $(this).height())/2 + 'px' )
};

// This bit has been added to the template by Gjalt-Jorn Peters (Greater Good)
// at the 13th of December 2015.
$(function() {
    
  // This removes the width attribute when the 'special semantic differential'
  // question is used. This makes it possible to determine the width of the
  // subquestions using the 'subquestion width' property.
  //$("div.answer:has('.scaletext') .col-responses .odd").removeAttr("width");
  //$("div.answer:has('.scaletext') .col-responses .even").removeAttr("width");
  //$("div.answer:has('.scaletext') .col-responses .odd").attr("width", "0%");
  //$("div.answer:has('.scaletext') .col-responses .even").attr("width", "0%");

  // Because by default, half the subquestion width is reserved for the right
  // side, we have to multiply this percentage by two.
  $("div.answer:has('.scaletext') .col-answers").attr('width', function(i, val) {
    //return("100%");
    return(((val.substring(0, val.length-1) * 2) - 2) + "%");
  });
  //$("div.answer:has('.scaletext') .col-answers").removeAttr('width');
  
  $("div.answer:has('.scaletext') .answertextright").attr('width', "2%");
    
  $('li.numberonly.withslider input').parent().nextAll('div.ui-slider').mousedown(function() {
    $(this).find('.ui-slider-handle').show();
  });
  
  
  $(window).load(function() {
    // this code will run after all other $(document).ready() scripts
    // have completely finished, AND all page elements are fully loaded.
  
    // Vertically center sliders; note that we need each because the parents'
    // height differs.
    $(".ui-slider").each(function() { $(this).verticalCenter() });

    // This is a bit of a responsive design hack, where the survey is made wider
    // if it contains tables that are wider than the current screen width.
    var widestTableWidth = 0;
    $("table").each(function() {
      widestTableWidth = Math.max(widestTableWidth, $(this).width());
    });
    if ($('#outer-wrapper').width() < (widestTableWidth+50)) {
      $('#outer-wrapper').css('min-width', widestTableWidth+50+"px");
    }
    
    // In the special 'frequency array questions', where people enter first a
    // number and then indicate the period, set the period to the last option
    // in the list by looking for the last radiobutton among the parent
    // elements' siblings.
    $('.multi-type-array').find('td.answer-item.text-item').find('input').change(function() {
      if( $(this).val() == 0) {
        $(this).parent().nextAll('.radio-item').last().find('input').click();
      }
    });

  }); // Close window load event handler
}); // Close document ready event handler
